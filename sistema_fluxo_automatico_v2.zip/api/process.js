import { writeFileSync } from 'fs';

export const config = {
  api: { bodyParser: false }
};

export default async function handler(req, res) {
  const content = Buffer.from("UEsFBgAAAAAAAAAAAAAAAAAAAAAAAA==", 'base64');
  res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition','attachment; filename=\"fluxo.xlsx\"');
  res.send(content);
}
