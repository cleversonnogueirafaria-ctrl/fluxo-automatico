async function enviar() {
    const receber = document.getElementById('receber').files[0];
    const pagar = document.getElementById('pagar').files[0];
    const div = document.getElementById('resultado');

    if(!receber || !pagar) {
        div.innerHTML = "<p style='color:red'>Envie os dois arquivos.</p>";
        return;
    }

    div.innerHTML = "Processando...";

    const formData = new FormData();
    formData.append("receber", receber);
    formData.append("pagar", pagar);

    const res = await fetch("/api/generate", { method: "POST", body: formData });
    const blob = await res.blob();

    const url = window.URL.createObjectURL(blob);
    div.innerHTML = `<a href='${url}' download='Fluxo_Consolidado.xlsx'>📥 Baixar Fluxo Consolidado</a>`;
}
