import { writeFileSync } from 'fs';
import OpenAI from "openai";

export const config = {
  api: { bodyParser: false }
};

export default async function handler(req, res) {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    const receberFile = req.files?.receber;
    const pagarFile = req.files?.pagar;

    const prompt = `
    APLIQUE TODA A AUTOMAÇÃO ESPECIFICADA POR CLEVERSON:
    - Tratar Contas a Receber conforme regras oficiais
    - Tratar Contas a Pagar conforme regras oficiais
    - Consolidar Receber + Pagar
    - Gerar arquivo final Excel com 3 abas
    - Entregar XLSX final
    `;

    const completion = await client.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
            { role: "system", content: "Você é especialista em Excel e automação financeira."},
            { role: "user", content: prompt }
        ],
        files: [
            receberFile,
            pagarFile
        ]
    });

    const file = completion.files[0];
    const bytes = await client.files.content(file.id);

    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.setHeader("Content-Disposition", "attachment; filename=Fluxo_Consolidado.xlsx");
    res.send(Buffer.from(await bytes.arrayBuffer()));
}
